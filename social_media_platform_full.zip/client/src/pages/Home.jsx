import { useEffect, useState } from 'react';
import axios from 'axios';

function Home() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchPosts = async () => {
      const res = await axios.get("/api/posts/feed");
      setPosts(res.data);
    };
    fetchPosts();
  }, []);

  return (
    <div>
      <h2>News Feed</h2>
      {posts.map(post => (
        <div key={post._id}>
          <p>{post.content}</p>
          {post.media && <img src={post.media} alt="media" width="200" />}
          <p>Likes: {post.likes.length}</p>
        </div>
      ))}
    </div>
  );
}

export default Home;
