const User = require("../models/User");

exports.getUser = async (req, res) => {
  const user = await User.findById(req.params.id).select("-password");
  if (!user) return res.status(404).json("User not found");
  res.json(user);
};

exports.followUser = async (req, res) => {
  const user = await User.findById(req.params.id);
  const currentUser = await User.findById(req.body.currentUserId);
  if (!user.followers.includes(req.body.currentUserId)) {
    await user.updateOne({ $push: { followers: req.body.currentUserId } });
    await currentUser.updateOne({ $push: { following: req.params.id } });
    res.status(200).json("User has been followed");
  } else {
    res.status(403).json("Already following this user");
  }
};
