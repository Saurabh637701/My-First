const express = require("express");
const { getUser, followUser } = require("../controllers/userController");

const router = express.Router();

router.get("/:id", getUser);
router.put("/:id/follow", followUser);

module.exports = router;
