const express = require("express");
const { createPost, getFeed, likePost } = require("../controllers/postController");

const router = express.Router();

router.post("/", createPost);
router.get("/feed", getFeed);
router.put("/:id/like", likePost);

module.exports = router;
